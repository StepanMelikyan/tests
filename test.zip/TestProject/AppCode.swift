//
//  AppCode.swift
//  TestProject
//
//  Created by Stepan on 12.01.2024.
//

import Foundation
struct AppCode {
    /// Здесь код Вашего приложения!
    static let appCode = "51696526"
}
