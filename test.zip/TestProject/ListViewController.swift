//
//  ListViewController.swift
//  test3
//
//  Created by Stepan on 12.01.2024.
//

import Foundation
import UIKit

class ListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    let data = [("folder", "Ваша папка 1"), ("folder", "Ваша папка 2"), ("folder", "Ваша папка 3")]

    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = .white
        title = "Список"

        let tableView = UITableView(frame: view.bounds, style: .plain)
        tableView.delegate = self
        tableView.dataSource = self
        view.addSubview(tableView)
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .subtitle, reuseIdentifier: nil)
        let (imageText, labelText) = data[indexPath.row]
        cell.textLabel?.text = labelText
        cell.imageView?.image = UIImage(systemName: imageText)
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let detailViewController = DetailViewController()
        let (imageText, labelText) = data[indexPath.row]
        detailViewController.imageText = imageText
        detailViewController.labelText = labelText
        navigationController?.pushViewController(detailViewController, animated: true)
    }
}
