//
//  DetailViewController.swift
//  test3
//
//  Created by Stepan on 12.01.2024.
//

// DetailViewController.swift

import UIKit
class DetailViewController: UIViewController {
    var imageText: String?
    var labelText: String?

    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = .white
        title = "Детали"

        let imageView = UIImageView(frame: CGRect(x: 100, y: 300, width: 200, height: 200))
        imageView.image = UIImage(systemName: imageText ?? "")
        view.addSubview(imageView)

        let label = UILabel(frame: CGRect(x: 140, y: 520, width: 200, height: 40))
        label.text = labelText
        view.addSubview(label)
    }
}
