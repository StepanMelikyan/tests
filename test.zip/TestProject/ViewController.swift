

import UIKit
import WebKit

class ViewController: UIViewController, WKNavigationDelegate {
    private lazy var webView: WKWebView = {
        let webView = WKWebView(frame: view.bounds)
        webView.navigationDelegate = self
        return webView
    }()


    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        view.addSubview(webView)
        
        let url = URL(string: "https://oauth.vk.com/authorize?client_id=" + AppCode.appCode + "&redirect_uri=https://oauth.vk.com/blank.html&scope=262150&display=mobile&response_type=token")
        webView.load(URLRequest(url: url!))
        super.viewDidLoad()
        
        

        let button = UIButton(type: .system)
        button.setTitle("Открыть список", for: .normal)
        button.frame = CGRect(x: 100, y: 300, width: 200, height: 100)
        button.addTarget(self, action: #selector(openList), for: .touchUpInside)
        view.addSubview(button)
    }

    @objc func openList() {
        let listViewController = ListViewController()
        navigationController?.pushViewController(listViewController, animated: true)
    }
}
